<!DOCTYPE html>
<html>
<head>
    <title>ClinicDesk Login</title>
</head>
<body>

<h2>Login</h2>

<form method="POST">

    <label>Email</label><br>
    <input type="email" name="email"><br><br>

    <label>Password</label><br>
    <input type="password" name="password"><br><br>

    <button type="submit">
        Login
    </button>

</form>

</body>
</html>